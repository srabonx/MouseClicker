import javax.swing.table.AbstractTableModel;
import java.util.List;

public class TableDataModel extends AbstractTableModel {

    private String[] COLUMNS = {"NUM","X LOC","Y LOC","DELAY(seconds)"};

    private List<TableData> tableDataList;

    public TableDataModel(List<TableData> tableDataList){
        this.tableDataList = tableDataList;
    }

    @Override
    public int getRowCount() {
        return tableDataList.size();
    }

    @Override
    public int getColumnCount() {
        return COLUMNS.length;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        return switch (columnIndex){
            case 0 -> tableDataList.get(rowIndex).getClickNum();
            case 1 -> tableDataList.get(rowIndex).getxLoc();
            case 2 -> tableDataList.get(rowIndex).getyLoc();
            case 3 -> tableDataList.get(rowIndex).getClickDelay()/1000; //to Show to second in the table
            default -> "-";
        };
    }

    @Override
    public String getColumnName(int column){
        return COLUMNS[column];
    }

    public void removeRow(int row){
        tableDataList.remove(row);
    }

}
