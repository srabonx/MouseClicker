import javax.swing.*;
import java.awt.*;

public class MainClass {

    public static void main(String[] args){

                MouseGui mg = new MouseGui();
                mg.setContentPane(mg.getMainPanel());
                mg.setTitle("Clicker");
                mg.setSize(460,320);
                mg.setLocationRelativeTo(null);
               // mg.pack();
                mg.setVisible(true);
                mg.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                new GlobalKeyMouseInput(mg);


    }

}

