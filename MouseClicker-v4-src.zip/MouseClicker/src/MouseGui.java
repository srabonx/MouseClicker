import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

public class MouseGui extends JFrame{

    private int xLoc, yLoc;
    private int clickDelay,loopTime;
    private int clickNum;
    private boolean clickStop = true;
    private LogicThread logicThread;

    private boolean isStartActive;
    private boolean xYGetLoc;

    private List<TableData> tableDataList;
    private TableDataModel tableDataModel;

    private int selectedRow;

    public MouseGui(){
            initializeComponent();
            tableDataList = new ArrayList<>();
            tableDataModel = new TableDataModel(tableDataList);
    }

    private void initializeComponent() {
        startButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                startButtonActionPerformed();
            }
        });
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopButtonActionPerformed();
            }
        });

        addBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addButtonActionPerformed();
            }
        });

        xYlocPickBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                xYGetLoc = true;
                xYlocPickBtn.setEnabled(false);
                setState(JFrame.ICONIFIED);
            }
        });

        aboutLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                if(e.getButton() == MouseEvent.BUTTON1) {
                    JOptionPane.showMessageDialog(null,"Mouse Clicker Version 4\nPress F6 for start and stop\n" +
                            "Add multiple clicks by first getting the location and then pressing \"ADD\"");
                }
            }
        });

        dataTable.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                if(e.getButton() == MouseEvent.BUTTON1)
                    dataTableMousePressed();
            }
        });

        removeBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                removeBtnActionPerformed();
            }
        });

    }

    private void removeBtnActionPerformed() {
        if(!dataTable.isRowSelected(selectedRow)){
            JOptionPane.showMessageDialog(null,"Select row to remove !");
            return;
        }
        tableDataModel.removeRow(selectedRow);
        tableDataModel = new TableDataModel(tableDataList);
        clickNum--;
        dataTable.setModel(tableDataModel);
    }

    private void dataTableMousePressed() {
        selectedRow = dataTable.getSelectedRow();
    }

    private void addButtonActionPerformed() {
        if(xLocTextField.getText().equals("") || yLocTextField.getText().equals("") || clickDelayTextField.getText().equals("")){
            JOptionPane.showMessageDialog(null,"Set Required Data!");
            return;
        }

        clickNum++;
        tableDataList.add(new TableData(this));
        tableDataModel = new TableDataModel(tableDataList);
        dataTable.setModel(tableDataModel);

        //clear text fields
        xLocTextField.setText("");
        yLocTextField.setText("");


    }


    public void stopButtonActionPerformed() {
        if(!isStartActive){
            JOptionPane.showMessageDialog(null,"Nothing to Stop");
            return;
        }

        isStartActive = false;
        clickStop = false;

        logicThread.stopLoop();

        clickDelayComboBox.setEnabled(true);
        loopTimeComboBox.setEnabled(true);
        addBtn.setEnabled(true);
        startButton.setEnabled(true);
        startButton.setText("START (F6)");
        setTitle("Clicker");

    }

    public void startButtonActionPerformed() {

        if(tableDataModel.getRowCount()==0 || tableDataModel==null){
            JOptionPane.showMessageDialog(null,"No Data");
            return;
        }

        isStartActive = true;

        getValueFromAllField();

        clickStop = true;

        logicThread = new LogicThread(this);
        logicThread.startLoop();
        setState(JFrame.ICONIFIED);

        startButton.setText("Running");
        setTitle("Clicker - Running");
        startButton.setEnabled(false);
        clickDelayComboBox.setEnabled(false);
        loopTimeComboBox.setEnabled(false);
        addBtn.setEnabled(false);
    }


    private void getValueFromAllField(){
        clickDelay = getValue(clickDelayComboBox , clickDelayTextField);
        loopTime = getValue(loopTimeComboBox , loopTimeTextField);
    }

    public int getValue(JComboBox comboBox , JTextField textField) {
        switch (comboBox.getSelectedIndex()){
            case 0:
                return 1000* Integer.parseInt(textField.getText().toString());
            case 1:
                return 1000*60*Integer.parseInt(textField.getText().toString());
            case 2:
                return 1000 * 60 * 60 * Integer.parseInt(textField.getText().toString());
            default:
                return 1;
        }
    }

    public int getxLoc() {
        return xLoc;
    }

    public int getyLoc() {
        return yLoc;
    }

    public int getClickDelay() {
        return clickDelay;
    }

    public int getLoopTime() {
        return loopTime;
    }

    public boolean isClickStop() {
        return clickStop;
    }

    public boolean isStartActive(){
        return isStartActive;
    }

    public boolean getxYGetLoc(){
        return xYGetLoc;
    }

    public void setIsStartActive(boolean isStartActive){
        this.isStartActive = isStartActive;
    }

    public void setXandYlocation(int index, Point point){

        if(index == 1){
            xLocTextField.setText(Integer.toString(point.x));
            yLocTextField.setText(Integer.toString(point.y));
        }
    }

    public void setxYLocPickBtn(boolean isEnabled){
        xYlocPickBtn.setEnabled(isEnabled);
    }

    public void setxYGetLoc(boolean isActive){
        xYGetLoc = isActive;
    }

    public JPanel getMainPanel(){
        return panel1;
    }

    public JTextField getXtextField(){
        return xLocTextField;
    }

    public JTextField getYtextField(){
        return yLocTextField;
    }

    public JTextField getClickDelayTextField(){
        return clickDelayTextField;
    }

    public JTextField getLoopTimeTextField(){
        return loopTimeTextField;
    }
    public int getClickNum(){
        return clickNum;
    }

    public JComboBox getClickDelayComboBox() {
        return clickDelayComboBox;
    }

    public TableModel getTableDataModel(){
        return tableDataModel;
    }
    public JTable getDataTable(){
        return dataTable;
    }

    private JPanel panel1;
    private JTextField xLocTextField;
    private JTextField yLocTextField;
    private JTextField clickDelayTextField;
    private JTextField loopTimeTextField;
    private JButton startButton;
    private JButton stopButton;
    private JLabel xAndYCoordinateLabelofFirstClick;
    private JComboBox clickDelayComboBox;
    private JComboBox loopTimeComboBox;
    private JButton xYlocPickBtn;
    private JLabel aboutLabel;
    private JTable dataTable;
    private JButton addBtn;
    private JScrollPane tableScrollPanel;
    private JButton removeBtn;
}
