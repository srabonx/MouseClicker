import java.util.List;

public class TableData {

    private int xLoc,yLoc,clickNum,clickDelay;
    MouseGui mouseGui;

    public TableData(MouseGui mouseGui){
        this.mouseGui = mouseGui;
        clickNum = mouseGui.getClickNum();
        xLoc = Integer.parseInt(mouseGui.getXtextField().getText());
        yLoc = Integer.parseInt(mouseGui.getYtextField().getText());
        clickDelay = mouseGui.getValue(mouseGui.getClickDelayComboBox(),mouseGui.getClickDelayTextField());
    }

    public int getxLoc() {
        return xLoc;
    }

    public int getyLoc() {
        return yLoc;
    }

    public int getClickNum() {
        return clickNum;
    }

    public int getClickDelay() {
        return clickDelay;
    }
}
