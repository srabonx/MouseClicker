import java.awt.*;
import java.awt.event.InputEvent;
import java.util.Objects;

public class LogicThread implements Runnable{

    private int xLoc, yLoc,clickDelay,loopTime;
    private boolean clickStop;
    private MouseGui mouseGui;
    private Robot robot;
    private Thread loopThread;

    public LogicThread(MouseGui mouseGui){
        this.mouseGui = mouseGui;

        this.loopTime = mouseGui.getLoopTime();
        this.clickStop = mouseGui.isClickStop();

        try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }

    }

    public void startLoop(){
        loopThread = new Thread(this);
        loopThread.start();
    }

    public void stopLoop(){
        loopThread.stop();
        mouseGui.getDataTable().clearSelection();
    }

    @Override
    public void run() {

        while(clickStop){

            try {

                for(int i=0;i<mouseGui.getTableDataModel().getRowCount();i++){
                         clickStop = mouseGui.isClickStop();
                         if(!clickStop)
                             return;

                        xLoc = Integer.parseInt(Objects.toString(mouseGui.getTableDataModel().getValueAt(i, 1)));
                        yLoc = Integer.parseInt(Objects.toString(mouseGui.getTableDataModel().getValueAt(i, 2)));
                        clickDelay = 1000 * Integer.parseInt(Objects.toString(mouseGui.getTableDataModel().getValueAt(i, 3)));
                        mouseGui.getDataTable().changeSelection(i,0,false,false);
                        robot.mouseMove(xLoc, yLoc);
                        robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                        robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

                        Thread.sleep(clickDelay);

                }

                Thread.sleep(loopTime);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
