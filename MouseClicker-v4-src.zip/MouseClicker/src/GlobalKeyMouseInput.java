import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseEvent;
import com.github.kwhat.jnativehook.mouse.NativeMouseListener;
import com.github.kwhat.jnativehook.mouse.NativeMouseMotionListener;

import javax.swing.*;
import java.awt.*;

public class GlobalKeyMouseInput implements NativeKeyListener, NativeMouseListener, NativeMouseMotionListener {

    MouseGui mouseGui;
    private int pressCount;

    public GlobalKeyMouseInput(MouseGui mouseGui){
        this.mouseGui = mouseGui;

        try {
            GlobalScreen.registerNativeHook();
        } catch (NativeHookException e) {
            throw new RuntimeException(e);
        }
        GlobalScreen.addNativeKeyListener(this);
        GlobalScreen.addNativeMouseListener(this);
        GlobalScreen.addNativeMouseMotionListener(this);
    }

    public void nativeKeyPressed(NativeKeyEvent e){

        if(e.getKeyCode() == NativeKeyEvent.VC_F6) {
            if(!mouseGui.isStartActive())
             mouseGui.startButtonActionPerformed();
            else
             mouseGui.stopButtonActionPerformed();
        }

    }

    public void nativeMousePressed(NativeMouseEvent e){
        if(e.getButton() == NativeMouseEvent.BUTTON1) {
            if (mouseGui.getxYGetLoc()) {
                Point point = new Point(e.getX(), e.getY());
                mouseGui.setXandYlocation(1, point);
                mouseGui.setxYLocPickBtn(true);
                mouseGui.setxYGetLoc(false);
                mouseGui.setState(JFrame.NORMAL);

            }
        }
    }

}
