import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MouseGui extends JFrame{

    private int firstX,firstY,secondX,secondY;
    private int clickDelay,loopTime;
    private boolean clickStop = true;
    private LogicThread logicThread;

    private boolean isStartActive;
    private boolean firstXyGetLoc,secondXyGetLoc;
    public MouseGui(){
            initializeComponent();
    }

    private void initializeComponent() {
        startButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                startButtonActionPerformed();
            }
        });
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopButtonActionPerformed();
            }
        });

        firstXyPickBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                firstXyGetLoc = true;
                firstXyPickBtn.setEnabled(false);
                setState(JFrame.ICONIFIED);
            }
        });

        secondXyPickBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                secondXyGetLoc = true;
                secondXyPickBtn.setEnabled(false);
                setState(JFrame.ICONIFIED);
            }
        });

        aboutLabel.addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent e) {
                super.mousePressed(e);
                if(e.getButton() == MouseEvent.BUTTON1) {
                    JOptionPane.showMessageDialog(null,"Mouse Clicker Version 3\nPress F6 for start and stop");
                }
            }
        });

    }


    public void stopButtonActionPerformed() {
        isStartActive = false;
        clickStop = false;

        clickDelayComboBox.setEnabled(true);
        loopTimeComboBox.setEnabled(true);
        startButton.setEnabled(true);
        startButton.setText("START (F6)");
        setTitle("Clicker");
    }

    public void startButtonActionPerformed() {

        isStartActive = true;

        getValueFromAllField();

        clickStop = true;
        logicThread = new LogicThread(this);
        logicThread.startLoop();
        setState(JFrame.ICONIFIED);

        startButton.setText("Running");
        setTitle("Clicker - Running");
        startButton.setEnabled(false);
        clickDelayComboBox.setEnabled(false);
        loopTimeComboBox.setEnabled(false);
    }


    private void getValueFromAllField(){
        firstX = Integer.parseInt(firstXtextField.getText().toString());
        firstY = Integer.parseInt(firstYTextField.getText().toString());
        secondX = Integer.parseInt((secondXtextField.getText().toString()));
        secondY = Integer.parseInt((secondYtextField.getText().toString()));

        clickDelay = getValue(clickDelayComboBox , clickDelayTextField);
        loopTime = getValue(loopTimeComboBox , loopTimeTextField);

    }

    private int getValue(JComboBox comboBox , JTextField textField) {
        switch (comboBox.getSelectedIndex()){
            case 0:
                return 1000* Integer.parseInt(textField.getText().toString());
            case 1:
                return 1000*60*Integer.parseInt(textField.getText().toString());
            case 2:
                return 1000 * 60 * 60 * Integer.parseInt(textField.getText().toString());
            default:
                return 1;
        }
    }

    public int getFirstX() {
        return firstX;
    }

    public int getFirstY() {
        return firstY;
    }

    public int getSecondX() {
        return secondX;
    }

    public int getSecondY() {
        return secondY;
    }

    public int getClickDelay() {
        return clickDelay;
    }

    public int getLoopTime() {
        return loopTime;
    }

    public boolean isClickStop() {
        return clickStop;
    }

    public boolean isStartActive(){
        return isStartActive;
    }

    public boolean getFirstXyGetLoc(){
        return firstXyGetLoc;
    }

    public boolean getSecondXyGetLoc(){
        return secondXyGetLoc;
    }

    public void setIsStartActive(boolean isStartActive){
        this.isStartActive = isStartActive;
    }

    public void setXandYlocation(int index, Point point){

        if(index == 1){
            firstXtextField.setText(Integer.toString(point.x));
            firstYTextField.setText(Integer.toString(point.y));
        }else{
            secondXtextField.setText(Integer.toString(point.x));
            secondYtextField.setText(Integer.toString(point.y));
        }
    }

    public void setFirstXandYpickBtn(boolean isEnabled){
        firstXyPickBtn.setEnabled(isEnabled);
    }
    public void setSecondXandYpickBtn(boolean isEnabled){
        secondXyPickBtn.setEnabled(isEnabled);
    }

    public void setFirstXyGetLoc(boolean isActive){
        firstXyGetLoc = isActive;
    }

    public void setSecondXyGetLoc(boolean isActive){
        secondXyGetLoc = isActive;
    }

    public JPanel getMainPanel(){
        return panel1;
    }

    private JPanel panel1;
    private JTextField firstXtextField;
    private JTextField firstYTextField;
    private JTextField secondXtextField;
    private JTextField secondYtextField;
    private JTextField clickDelayTextField;
    private JTextField loopTimeTextField;
    private JButton startButton;
    private JButton stopButton;
    private JLabel xAndYCoordinateLabelofFirstClick;
    private JLabel xAndYCoordinateLabelofSecondClick;
    private JComboBox clickDelayComboBox;
    private JComboBox loopTimeComboBox;
    private JButton firstXyPickBtn;
    private JButton secondXyPickBtn;
    private JLabel aboutLabel;
}
