import java.awt.*;
import java.awt.event.InputEvent;

public class LogicThread implements Runnable{

    private int firstX,firstY,secondX,secondY,clickDelay,loopTime;
    private boolean clickStop;
    private MouseGui mouseGui;
    private Robot robot;
    private Thread loopThread;

    public LogicThread(MouseGui mouseGui){
        this.mouseGui = mouseGui;

        this.firstX = mouseGui.getFirstX();
        this.firstY = mouseGui.getFirstY();
        this.secondX = mouseGui.getSecondX();
        this.secondY = mouseGui.getSecondY();
        this.clickDelay = mouseGui.getClickDelay();
        this.loopTime = mouseGui.getLoopTime();
        this.clickStop = mouseGui.isClickStop();
        try {
            robot = new Robot();
        } catch (AWTException e) {
            throw new RuntimeException(e);
        }

    }

    public void startLoop(){
        loopThread = new Thread(this);
        loopThread.start();
    }

    @Override
    public void run() {

        while(clickStop){


            try {

                robot.mouseMove(firstX,firstY);
                robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

                Thread.sleep(clickDelay);

                robot.mouseMove(secondX,secondY);
                robot.mousePress(InputEvent.BUTTON1_DOWN_MASK);
                robot.mouseRelease(InputEvent.BUTTON1_DOWN_MASK);

                Thread.sleep(loopTime);

            } catch (InterruptedException e) {
                throw new RuntimeException(e);
            }

            clickStop = mouseGui.isClickStop();
        }

    }
}
