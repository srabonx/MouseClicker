import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class MouseGui extends JFrame{

    private int firstX,firstY,secondX,secondY;
    private int clickDelay,loopTime;
    private boolean clickStop = true;
    private LogicThread logicThread;
    public MouseGui(){
            initializeComponent();
    }

    private void initializeComponent() {
        startButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                startButtonActionPermormed(e);
            }
        });
        stopButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                stopButtonActionPerformed(e);
            }
        });
    }


    private void stopButtonActionPerformed(ActionEvent e) {
        clickStop = false;
        System.out.println("stop pressed");
    }

    private void startButtonActionPermormed(ActionEvent e) {
        firstX = Integer.parseInt(firstXtextField.getText().toString());
        firstY = Integer.parseInt(firstYTextField.getText().toString());
        secondX = Integer.parseInt((secondXtextField.getText().toString()));
        secondY = Integer.parseInt((secondYtextField.getText().toString()));
        clickDelay = 1000 * Integer.parseInt(clickDelayTextField.getText().toString());
        loopTime = 1000 * Integer.parseInt((loopTimeTextField.getText().toString()));
        System.out.println("start pressed");

        logicThread = new LogicThread(this);
        logicThread.startLoop();
        setState(JFrame.ICONIFIED);
        System.out.println("start after");
    }

    public int getFirstX() {
        return firstX;
    }

    public int getFirstY() {
        return firstY;
    }

    public int getSecondX() {
        return secondX;
    }

    public int getSecondY() {
        return secondY;
    }

    public int getClickDelay() {
        return clickDelay;
    }

    public int getLoopTime() {
        return loopTime;
    }

    public boolean isClickStop() {
        return clickStop;
    }

    public JPanel getMainPanel(){
        return panel1;
    }

    private JPanel panel1;
    private JTextField firstXtextField;
    private JTextField firstYTextField;
    private JTextField secondXtextField;
    private JTextField secondYtextField;
    private JTextField clickDelayTextField;
    private JTextField loopTimeTextField;
    private JButton startButton;
    private JButton stopButton;
}
